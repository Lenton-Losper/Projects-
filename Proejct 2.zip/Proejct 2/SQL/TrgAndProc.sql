-- Step 0: Create the Database
CREATE DATABASE CloudBasedSystem;

GO

USE master;
GO

-- Step 1: Create Users Table
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    FullName NVARCHAR(100),
    Email NVARCHAR(100) NOT NULL UNIQUE,
    CreatedAt DATE DEFAULT GETDATE()
);
GO

-- Step 2: Create Roles Table
CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE  -- Example roles: 'Admin', 'User', etc.
);
GO

-- Step 3: Alter Users Table to add RoleID as a Foreign Key
ALTER TABLE Users
ADD RoleID INT,
CONSTRAINT FK_User_Role FOREIGN KEY (RoleID) REFERENCES Roles(RoleID);
GO

-- Step 4: Create Projects Table
CREATE TABLE Projects (
    ProjectID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectName NVARCHAR(255) NOT NULL,
    Description NVARCHAR(500),
    CreatedBy INT,  -- Links to Users (UserID)
    CreatedAt DATE DEFAULT GETDATE(),
    FOREIGN KEY (CreatedBy) REFERENCES Users(UserID)
);
GO

-- Step 5: Create Collaborations Table
CREATE TABLE Collaborations (
    CollaborationID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,  -- Links to Users
    ProjectID INT,  -- Links to Projects
    RoleInProject NVARCHAR(255),  -- Role of the user in this project (e.g., Designer, Reviewer)
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID)
);
GO

-- Step 6: Create DesignAssets Table
CREATE TABLE DesignAssets (
    AssetID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID INT,  -- Links to Projects
    AssetName NVARCHAR(255) NOT NULL,
    Description NVARCHAR(500),
    CreatedAt DATE DEFAULT GETDATE(),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID) ON DELETE CASCADE
);
GO

-- Step 7: Create Files Table
CREATE TABLE Files (
    FileID INT IDENTITY(1,1) PRIMARY KEY,
    AssetID INT,  -- Links to DesignAssets
    FileName NVARCHAR(255) NOT NULL,
    FileType NVARCHAR(50),  -- E.g., jpg, png, pdf, docx, etc.
    FileSize INT,  -- Size in KB/MB
    UploadedDate DATE DEFAULT GETDATE(),
    FilePath NVARCHAR(500),  -- File storage location in the cloud
    FOREIGN KEY (AssetID) REFERENCES DesignAssets(AssetID) ON DELETE CASCADE
);
GO

-- Step 8: Create Notifications Table
CREATE TABLE Notifications (
    NotificationID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,  -- User receiving the notification
    Message NVARCHAR(255),  -- Notification content
    IsRead BIT DEFAULT 0,  -- Flag to track if the notification has been read (0 = Unread, 1 = Read)
    CreatedAt DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

GO
-- Step 9: Stored Procedure to Add a New Project
CREATE PROCEDURE AddProject
    @ProjectName NVARCHAR(255),
    @Description NVARCHAR(500),
    @CreatedBy INT
AS
BEGIN
    BEGIN 
	TRY
        INSERT INTO Projects (ProjectName, Description, CreatedBy)
        VALUES (@ProjectName, @Description, @CreatedBy);
        
        PRINT 'Project added successfully';
    END TRY
    BEGIN CATCH
        PRINT 'Error occurred: ' + ERROR_MESSAGE();
    END CATCH;
END;

GO
CREATE PROCEDURE UploadFile
    @FileName NVARCHAR(255),
    @ProjectId INT
AS
BEGIN
    INSERT INTO Files (FileName, ProjectID)
    VALUES (@FileName, @ProjectId);
END;


-- Step 10: Stored Procedure to Get All Projects by User
GO
CREATE PROCEDURE GetProjectsByUser
    @UserID INT
AS
BEGIN
    SELECT P.ProjectID, P.ProjectName, P.Description, P.CreatedAt
    FROM Projects P
    WHERE P.CreatedBy = @UserID;
END;
GO

-- Step 11: Function to Calculate Total File Size for a Project
CREATE FUNCTION GetTotalFileSize(@ProjectID INT)
RETURNS INT
AS
BEGIN
    DECLARE @TotalSize INT;
    
    SELECT @TotalSize = SUM(FileSize)
    FROM Files F
    JOIN DesignAssets D ON F.AssetID = D.AssetID
    WHERE D.ProjectID = @ProjectID;
    
    RETURN ISNULL(@TotalSize, 0);
END;
GO

-- Step 12: Trigger to Automatically Notify Admin When a New Project is Added
CREATE TRIGGER NotifyAdminOnNewProject
ON Projects
AFTER INSERT
AS
BEGIN
    DECLARE @AdminID INT;
    DECLARE @NewProjectID INT;

    -- Get the Admin user (assuming Admin role is RoleID = 1)
    SELECT @AdminID = UserID FROM Users WHERE RoleID = 1;
    
    -- Get the new project ID
    SELECT @NewProjectID = ProjectID FROM inserted;

    -- Insert a notification for the Admin
    INSERT INTO Notifications (UserID, Message)
    VALUES (@AdminID, 'A new project has been created: ' + (SELECT ProjectName FROM Projects WHERE ProjectID = @NewProjectID));
END;
GO

-- Step 13: Cursor to Loop Through Projects and Print Their Total File Size
DECLARE @ProjectID INT, @ProjectName NVARCHAR(255), @TotalFileSize INT;

DECLARE ProjectCursor CURSOR FOR
SELECT ProjectID, ProjectName FROM Projects;

OPEN ProjectCursor;

FETCH NEXT FROM ProjectCursor INTO @ProjectID, @ProjectName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Get total file size for each project
    SET @TotalFileSize = dbo.GetTotalFileSize(@ProjectID);
    
    PRINT 'Project: ' + @ProjectName + ', Total File Size: ' + CAST(@TotalFileSize AS NVARCHAR);
    
    FETCH NEXT FROM ProjectCursor INTO @ProjectID, @ProjectName;
END;

CLOSE ProjectCursor;
DEALLOCATE ProjectCursor;
GO

-- Step 14: Insert Sample Data into Roles Table
INSERT INTO Roles (RoleName) VALUES ('Admin'), ('User');
GO

-- Step 15: Insert Sample Data into Users Table
INSERT INTO Users (Username, Password, FullName, Email, RoleID) 
VALUES ('admin01', 'hashedpassword1', 'Admin One', 'admin01@cloud.com', 1),  -- Admin
       ('user01', 'hashedpassword2', 'User One', 'user01@cloud.com', 2);  -- Regular User
GO

-- Step 16: Insert Sample Data into Projects Table
INSERT INTO Projects (ProjectName, Description, CreatedBy) 
VALUES ('Project Alpha', 'A project for advanced design', 1),  -- Created by Admin
       ('Project Beta', 'A simple design project', 2);  -- Created by Regular User
GO

-- Step 17: Insert Sample Data into Collaborations Table
INSERT INTO Collaborations (UserID, ProjectID, RoleInProject)
VALUES (1, 1, 'Lead Designer'),  -- Admin as Lead Designer on Project Alpha
       (2, 1, 'Assistant Designer'),  -- User as Assistant Designer on Project Alpha
       (2, 2, 'Solo Designer');  -- User as Solo Designer on Project Beta
GO

-- Step 18: Insert Sample Data into DesignAssets Table
INSERT INTO DesignAssets (ProjectID, AssetName, Description) 
VALUES (1, 'Landing Page Design', 'The main landing page for Project Alpha'),
       (2, 'Logo Design', 'Logo for Project Beta');
GO

-- Step 19: Insert Sample Data into Files Table
INSERT INTO Files (AssetID, FileName, FileType, FileSize, FilePath) 
VALUES (1, 'landing_page.jpg', 'jpg', 500, '/uploads/project_alpha/landing_page.jpg'),
       (2, 'logo.png', 'png', 200, '/uploads/project_beta/logo.png');
GO

-- Step 20: Insert Sample Data into Notifications Table
INSERT INTO Notifications (UserID, Message)
VALUES (1, 'New file uploaded to Project Alpha'),
       (2, 'You have been assigned to Project Alpha as Assistant Designer');
GO
